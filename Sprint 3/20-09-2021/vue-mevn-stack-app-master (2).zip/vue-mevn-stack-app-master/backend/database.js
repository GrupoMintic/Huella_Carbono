module.exports = {
  db: "mongodb://localhost:27017/huella_de_carbono",
};
