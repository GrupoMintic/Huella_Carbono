<template>
  <div class="row justify-content-center">
    <div class="col-md-6 colorfuente">
      <h3 class="text-center">Log in</h3>

      <div class="card" style= "background:green;color:white">
        
        <div class="card-body">
          <form @submit.prevent="handleSubmitForm">
            <div class="form-group mt-1">
              <label>Usuario</label>
              <input
                type="text"
                class="form-control"
                v-model="student.Usuario"
                required
              />
            </div>
            <!-- <div class="form-group">
          <label>Email</label>
          <input
            type="email"
            class="form-control"
            v-model="student.email"
            required
          />
        </div> -->
            <div class="form-group mt-3">
              <label>Contraseña</label>
              <input
                type="text"
                class="form-control mt-1"
                v-model="student.Pass"
                required
              />
            </div>
            <div class="form-group mt-3">
              <button class="btn btn-primary btn-block">Ingresar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  data() {
    return {
      student: {
        name: "",
        email: "",
        phone: "",
      },
    };
  },
  methods: {
    handleSubmitForm() {
      let apiURL = "http://localhost:4000/api/create-student";

      axios
        .post(apiURL, this.student)
        .then(() => {
          this.$router.push("/view");
          this.student = {
            name: "",
            email: "",
            phone: "",
          };
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
};
</script>
