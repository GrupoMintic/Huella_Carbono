<template>
  <div class="container colorfuente">
    <h1 class=  "text-center mb-20"  > Menu </h1>

  <div class="row">
    <div class="col-sm">
     <div class="news-image">
            <img src="../../public/css/Bosque home.jpg" height="200px" width="350px" />
          </div>
          <div class="news-text">
            <h2 class="news-title">Tips de Cuidado Ambiental</h2>
            <hr />
            <p class="news-info" style="margin: 0; padding: 0">
              Aprende sobre la huella de carbono ademas de tips para prevenirla
            </p>
            <input type="button" value="Leer mas" style="float: right;">
          </div>
    </div>
    <div class="col-sm">
       <div class="news-image">
            <img src="../../public/css/calculadora.jpg" height="200px" width="350px" />
          </div>
          <div class="news-text">
            <h2 class="news-title">Calculadora de huella de Carbono</h2>
            <hr />
            <p class="news-info" style="margin: 0; padding: 0">
              Calcula tu huella de carbono aqui
            </p>
            <input type="button" value="Calcular" style="float: right;">

          </div>
        </div>
    </div>
  </div>
</template>
<script>