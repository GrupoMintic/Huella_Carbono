<template>
  <div id="app" style="color: white;">
    <div id="nav">
      <router-link to="/" style="color: white;">Inicio</router-link>|
      <router-link to="/menu" style="color: white;">Menú</router-link>|
      <router-link to="/tips" style="color: white;">Tips</router-link>|
      <router-link to="/calculo" style="color: white;">Calcular Huella CO2</router-link>|
      <router-link to="/login" style="color: white;">Ingreso Admon</router-link>|
      <router-link to="/allhuellas" style="color: white;">CRUD</router-link>
    </div>
    <router-view/>
  </div>
</template>

<style lang="sccs">

</style>