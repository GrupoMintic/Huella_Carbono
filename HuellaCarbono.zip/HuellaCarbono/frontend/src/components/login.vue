<template>
  <div class="row justify-content-center">
      <div style="color:white;">
        <h1>INGRESO ADMINISTRADOR - LOGIN</h1>
      </div>
    <div class="col-md-4">
      <form @submit.prevent="handleSubmitForm">
        <div class="form-group" style="color:white;">
          <br>
          <label>Ingrese su usuario</label>
          <br>
          <input
            type="text"
            class="form-control"
            width="30"
            height="30"
            v-model="log_in.user"
            maxlength="10"
            required
          />
        </div>
        <div class="form-group" style="color:white;">
            <label>Ingrese su Clave</label>
            <br>
            <input
                type="text"
                class="form-control"
                width="30"
                height="30"
                v-model="log_in.pass"
                maxlength="10"
                required
            />
        </div>
        <div class="form-group my-2">
            <b-button class="btn-warning btn-sm mx-2" @click="ingresarAdmin(item._id)">Ingresar</b-button>                                   
        </div>        
      </form>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return { log_in: { user: "", pass: "" } };
  },
  methods: { handleSubmitForm() {} },
};
</script>