import express from "express";
import morgan from "morgan";
import cors from "cors";
import path from "path";

const app = express();

//CONEXION A BASE DE DATOS
const mongoose = require("mongoose");
const uri = "mongodb://localhost:27017/huelladb";
const options = { useNewUrlParser: true, useUnifiedTopology: true }; // Or using promises 
mongoose.connect(uri, options).then( 
    () => { /** ready to use. The `mongoose.connect()` promise resolves to mongoose instance. */ 
        console.log('Conectado a DB') 
    }, 
    err => {  /** handle initial connection error */ 
        console.log(err) 
    } );
//MIDDLEWARE
app.use(morgan("tiny"));
app.use(cors());
app.use(express.json());
//application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

//RUTAS

app.use('/api', require('./routes/resultados'));
app.use('/api', require('./routes/preguntas'));
app.use('/api', require('./routes/admonData'));

//Directorio Cliente
const history = require("connect-history-api-fallback");
app.use(history());
app.use(express.static(path.join(__dirname, "public")));

//PUERTO
app.set("puerto", process.env.PORT || 3000);
app.listen(app.get("puerto"), function() {
  console.log("Conectando en el puerto: " + app.get("puerto"));
});

