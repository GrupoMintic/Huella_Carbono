import mongoose from "mongoose";
const Schema = mongoose.Schema;

const resultadoSchema = new Schema(
    {
        nombre: 
        { 
            type: String, required: [true, "Nombre obligatorio"] 
        },
        valorHuella: 
        {
            type: Number, required: true
        },
        fecha: 
        { 
            type: Date, 
            default: Date.now 
        },
});

//Convertir a modelo

const resultado = mongoose.model('resultado', resultadoSchema); 
export default resultado;
