import mongoose from "mongoose";
const Schema = mongoose.Schema;

const admonSchema = new Schema(
    {
        id: 
        { 
            type: Number, required: [true, "ID Obligatorio"] 
        },
        nombre: 
        {
            type: String, required: true
        },
});

//Convertir a modelo

const admonData = mongoose.model('admonData', admonSchema); 
export default admonData;