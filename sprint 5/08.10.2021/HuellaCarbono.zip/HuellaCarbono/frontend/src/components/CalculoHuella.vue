<template>
<div class="container" style="color:white;">
  <h1>CALCULO HUELLA DE CARBONO</h1>


  <form @submit.prevent="agregarHuella()">
    <input
      type="text"
      class="form-control my-2"
      placeholder="INGRESE SU NOMBRE"
      v-model="calc.nombre"
      required
    >
    <label>* Vivienda</label>
    <label>1. Cuántas personas viven en su núcleo familiar</label>
    <input
      type="number"
      class="form-control my-2"
      placeholder="INGRESE LA CANTIDAD DE PERSONAS QUE VIVEN EN SU CASA"
    >
    <label>2. Cuántos vatios consumen en su hogar</label>
    <input
      type="number"
      class="form-control my-2"
      placeholder="CONSUMO DE VATIOS EN EL RECIBO DE CODENSA"
      v-model="calc.valorHuella"
      required
    >
    <label>3. Indique la cantidad de metros de gas consumidos</label>
    <input
      type="number"
      class="form-control my-2"
      placeholder="CONSUMO DE METROS CUBICOS EN EL RECIBO VANTI"
    >

    <label class="mr-3"
      >1. Posees Vehiculo propio &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    </label>
    <label class="mr-3" for="SI">SI &nbsp; </label>
    <input type="radio" id="radiobtn1" name="tiene_carro" value="SI">
    <label class="mr-3" for="NO">NO &nbsp; </label>
    <input type="radio" id="radiobtn2" name="tiene_carro" value="NO" checked="true">
    <br>
    <label>2. Cantidad de galones al mes</label>
    <input type="number" class="form-control" required>        

    <b-button class="btn-success my-2" type="submit">Agregar</b-button>

  </form>
</div>
</template>

<script>
export default {

    data() {
        return {

            /*huellas: [],/*arreglo*/
            /*mensaje: {color: 'success', texto: ''}, 
            dismissSecs: 5, 
            dismissCountDown: 0,*/
       
            /*calc: { nombre: "", personas: "", vatios: "", gas: "", transp: "", gals: "", huella: "" },*/
            calc: { nombre: "", valorHuella:""},
            /*resultHuella: {nombre: "", huellaR: ""},*/
        }

    },

    created() {

      
    },

    methods: {
      agregarHuella() {
          /*this.resultHuella.nombre = this.calc.nombre;
          this.resultHuella.huellaR = this.calc.personas+this.calc.vatios+this.calc.gas+this.calc.transp*2+
          this.calc.gals;*/
          this.axios.post('/nuevoResultado', this.calc)
          .then(res => {
            /*this.calc.push(res.data)
            this.calc.nombre="";
            this.calc.descripcion="";
            this.mensaje.color="success";
            this.mensaje.texto="Huella Calculada";
            this.showAlert();*/
            console.log('Mensaje servidor'+res)
      
          }).catch((e) => {
            console.log(e.response);            
          });
  } },

        countDownChanged(dismissCountDown) { 
            this.dismissCountDown = dismissCountDown 
        }, 
        showAlert() { 
            this.dismissCountDown = this.dismissSecs 
        }

    }


</script>
