<template>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <h3 class="text-center" style="color: white">
        ¿ Qué es la Huella de Carbono ?
      </h3>

      <div class="card" style="color: black">
        <div class="card-body">
          <form @submit.prevent="handleSubmitForm">
            <div class="form-group mt-1">
              <p>
                La huella de carbono es un indicador que representa la cantidad
                total de Gases de Efecto Invernadero (GEI) que emite directa o
                indirectamente un individuo, una organización, la realización de
                un evento o la fabricación de un producto. Su unidad es la masa
                (kilogramos o toneladas) de Dióxido de Carbono equivalente
                (CO2-e)
              </p>
              <img
                width="500"
                height="400"
                src="../../public/css/Bosque home.jpg"
              />
            </div>
          </form>
        </div>
      </div>
      <h3 class="text-center" style="color: white">
        Tips de Cuidado Ambiental
      </h3>

      <div class="card" style="background:grey;color:blac">
        <div class="card-body">
          <form @submit.prevent="handleSubmitForm">
            <div class="form-group mt-1">
              <label
                >* Muévete bien 
                Puede que sea más cómodo viajar en tu vehículo,pero recuerda que también existe la bicicleta. Tu cuerpo y tu
                planeta te lo agradecerán. 
                * ¿Sabías que tus aparatos consumen energía aún cuando están apagados? 
                La mayoría de dispositivos consumen energía aún cuando aparentemente no están encendidos.
                Por ello, desenchufa aquellos cables que no estés utilizando.
                 <img
                width="500"
                height="400"
                src="../../public/css/Contaminacion.jpg"
              />
              </label>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>