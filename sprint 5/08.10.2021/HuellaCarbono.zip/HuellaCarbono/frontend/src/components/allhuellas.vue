<template>
    <div style="color:white;" >
        <h1>CRUD HUELLAS DE CARBONO</h1>
        <table class="table" style= "border: 1px solid white;">
        <thead>
            <tr>
                <th scope="col" style= "border: 1px solid white; color:white;">ID</th>
                <th scope="col" style= "border: 1px solid white; color:white;">NOMBRE</th>
                <th scope="col" style= "border: 1px solid white; color:white;">VALOR HUELLA</th>
                <th scope="col" style= "border: 1px solid white; color:white;">ACCION</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="(item, index) in huellas" :key="index">
                <th scope="row" style= "border: 1px solid white; color:white;">{{item._id}}</th>
                <td style= "border: 1px solid white; color:white;">{{item.nombre}}</td>
                <td style= "border: 1px solid white; color:white;">{{item.valorHuella}}</td>
                <td><b-button class="btn-warning btn-sm mx-2" @click="EdicionHuella(item._id)">Actualizar</b-button> 
                <b-button class="btn-danger btn-sm mx-2" @click="eliminarHuella(item._id)">Eliminar</b-button>
                </td>
            </tr>
        </tbody>
        </table>             
    </div>
</template>

<script>
export default {

    data(){
        return{
            huellas:[]
        }
    },
    created() {
        this.listarHuellas()
    },

    methods: {
        listarHuellas(){
            this.axios.get('/resultado').
                then(res=>{

                    console.log(res.data);
                    this.huellas = res.data;
                })
                .catch(e=>{
                    console.log(e.response);
                })
        },
        eliminarHuella(id){

            this.axios.delete(`/resultado/${id}`)
            .then(res=>{
                this.listarHuellas();
                /*const index = this.huellas.findIndex(item=> item._id===res.data._id);
                this.notas.splice(index, 1);
                this.mensaje.color="success";
                this.mensaje.texto="Huella Eliminada";
                this.showAlert();*/


            })
            .catch(e=>{

                  console.log(e.response);

            })
        },

        activarEdicion(id){

            this.editar=true;
            this.axios.get(`/nota/${id}`)
            .then(res=>{

                this.notaEditar=res.data;

            })
            .catch(e=>{

                 console.log(e.response);


            })


        },

        editarNota(item){
            
            this.axios.put(`/nota/${item._id}`, item)
            .then(res=>{
                const index= this.notas.findIndex(n=> n._id===res.data._id);
                this.notas[index].nombre=res.data.nombre;
                this.notas[index].descripcion=res.data.descripcion;
                this.mensaje.color="success";
                this.mensaje.texto="Nota Editada";
                this.showAlert();
                this.editar=false;


            })
            .catch(e=>{

                console.log(e.response);

            })



        },

    },
    
}
</script>