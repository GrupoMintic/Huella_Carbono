import express from "express";
const router = express.Router(); 
import resultado from "../models/admonData"; // importar el modelo nota
//Create
router.post("/admon", async (req, res) => {// Agregar un resultado de huella a la base de datos
  const body = req.body;
  try {
    const huellaDB = await resultado.create(body);
    res.status(200).json(huellaDB);
  } catch (error) {
    return res.status(500).json(
        { 
            mensaje: "Ocurrio un error", error 
        });
  }
}); 

//Read
router.get('/admon/:id', async(req, res) => { 
    const _id = req.params.id; 
    try 
    { 
        const huellaDB = await resultado.findOne({_id}); 
        res.json(huellaDB); 
    } catch (error) 
    { 
        return res.status(400).json({ mensaje: 'Ocurrio un error', error })
    } 
});
// Get con todos los documentos 
router.get('/admon', async(req, res) => { 
    try 
    { 
        const huellaDB = await resultado.find(); 
        res.json(huellaDB); 
    } catch (error) 
    { 
        return res.status(400).json({ mensaje: 'Ocurrio un error', error }) 
    } 
});

//Update
router.put('/admon/:id', async(req, res) => { 
    const _id = req.params.id; 
    const body = req.body; 
    try 
    { 
        const huellaDB = await resultado.findByIdAndUpdate(_id, body, {new: true}); 
        res.json(huellaDB); 
    } catch (error) 
    { 
        return res.status(400).json({ mensaje: 'Ocurrio un error', error }) 
    } 
});

//Delete
router.delete('/admon/:id', async(req, res) => { 
    const _id = req.params.id; 
    try 
    { 
        const huellaDB = await resultado.findByIdAndDelete({_id}); 
        if(!huellaDB)
        { 
            return res.status(400).json({ mensaje: 'No se encontró el id indicado', error }) 
        } 
        res.json(huellaDB); 
    } catch (error) 
    { 
        return res.status(400).json({ mensaje: 'Ocurrio un error', error }) 
    } 
});


// Exportamos la configuración de express app module.exports = router;
module.exports = router;