import mongoose from "mongoose";
const Schema = mongoose.Schema;

const preguntasSchema = new Schema(
    {
        id: 
        { 
            type: Number, required: [true, "ID Obligatorio"] 
        },
        descripcion: 
        {
            type: String, required: true
        },
        ponderacion: 
        { 
            type: Number, 
            required: true
        },
});

//Convertir a modelo

const preguntas = mongoose.model('preguntas', preguntasSchema); 
export default preguntas;